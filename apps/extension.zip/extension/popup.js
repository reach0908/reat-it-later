// DOM 요소
const statusElement = document.getElementById("status");
const extractButton = document.getElementById("extractButton");
const errorElement = document.getElementById("error");

// 현재 탭이 유튜브 영상 페이지인지 확인
async function checkCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    if (!tab.url) {
      updateStatus("페이지를 찾을 수 없습니다.", true);
      return;
    }

    const url = new URL(tab.url);
    if (url.hostname === "www.youtube.com" && url.pathname === "/watch") {
      const videoId = url.searchParams.get("v");
      if (videoId) {
        updateStatus("유튜브 영상이 감지되었습니다.", false);
        extractButton.disabled = false;
        return;
      }
    }

    updateStatus("유튜브 영상 페이지가 아닙니다.", true);
  } catch (error) {
    updateStatus("오류가 발생했습니다.", true);
    showError(error.message);
  }
}

// 상태 업데이트
function updateStatus(message, isError = false) {
  statusElement.textContent = message;
  statusElement.style.backgroundColor = isError ? "#fee2e2" : "#f3f4f6";
  errorElement.style.display = "none";
}

// 에러 표시
function showError(message) {
  errorElement.textContent = message;
  errorElement.style.display = "block";
}

// 스크립트 추출
async function extractScript() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    // content script에 메시지 전송
    chrome.tabs.sendMessage(tab.id, { action: "extractScript" }, (response) => {
      if (chrome.runtime.lastError) {
        showError("콘텐츠 스크립트와 통신할 수 없습니다.");
        return;
      }

      if (response.error) {
        updateStatus("스크립트 추출 실패", true);
        showError(response.error);
      } else {
        updateStatus("스크립트 추출 완료!");
        // 추출된 스크립트를 서버로 전송하거나 저장
        saveScript(response.script);
      }
    });
  } catch (error) {
    updateStatus("오류가 발생했습니다.", true);
    showError(error.message);
  }
}

// 스크립트 저장
async function saveScript(script) {
  try {
    // TODO: 서버로 스크립트 전송
    console.log("Extracted script:", script);
  } catch (error) {
    showError("스크립트 저장 중 오류가 발생했습니다.");
  }
}

// 이벤트 리스너
extractButton.addEventListener("click", extractScript);

// 초기화
document.addEventListener("DOMContentLoaded", checkCurrentPage);
