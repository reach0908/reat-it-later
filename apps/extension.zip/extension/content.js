// 스크립트 추출 함수
async function extractYoutubeScript() {
  try {
    // 자막 버튼 찾기
    const captionButton = document.querySelector(".ytp-subtitles-button");
    if (!captionButton) {
      return { error: "자막을 찾을 수 없습니다." };
    }

    // 자막이 비활성화되어 있다면 활성화
    if (!captionButton.getAttribute("aria-pressed") === "true") {
      captionButton.click();
    }

    // 자막 텍스트 컨테이너 찾기
    const captionWindow = document.querySelector(
      ".ytp-caption-window-container"
    );
    if (!captionWindow) {
      return { error: "자막 컨테이너를 찾을 수 없습니다." };
    }

    // 영상 정보 가져오기
    const title = document
      .querySelector("h1.ytd-video-primary-info-renderer")
      ?.textContent?.trim();
    const channelName = document
      .querySelector("ytd-channel-name yt-formatted-string a")
      ?.textContent?.trim();
    const videoId = new URL(window.location.href).searchParams.get("v");

    // 자막 텍스트 수집
    const captions = [];
    const captionObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "childList") {
          const captionText = mutation.target.textContent?.trim();
          if (captionText && !captions.includes(captionText)) {
            captions.push(captionText);
          }
        }
      });
    });

    // 자막 변화 감지 시작
    captionObserver.observe(captionWindow, {
      childList: true,
      subtree: true,
    });

    // 15초 동안 자막 수집 후 반환
    await new Promise((resolve) => setTimeout(resolve, 15000));
    captionObserver.disconnect();

    return {
      script: {
        videoId,
        title,
        channelName,
        captions: captions.join("\n"),
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error) {
    return { error: error.message };
  }
}

// 메시지 리스너
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractScript") {
    extractYoutubeScript().then(sendResponse);
    return true; // 비동기 응답을 위해 true 반환
  }
});
